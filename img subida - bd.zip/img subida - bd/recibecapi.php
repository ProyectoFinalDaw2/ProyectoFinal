<?php
	//require_once '../db/db_connect.php';
	function conectar()
	{
	$ip = 'localhost';
	$usuari = 'root';
	$password = '1234';
	$db_name = 'mangas';
	
	$con = mysqli_connect($ip,$usuari,$password);
	mysqli_select_db($con,$db_name);
	
	return $con;
	}
	$con=conectar();
	
	
	session_start();
	#nombre de usuario
	$nom=$_REQUEST["txtnom"]; 
	#manga cuando se envia desde capitulo y el manga ya existe.
	if(isset($_POST["manga"]))
	{
	$manga=$_POST["manga"]; 
	}
	#seleccionamos la version
	if(isset($_POST["version"]))
	{
	$version=$_POST["version"];   //version del manga  esp o ingles
	}	
	#numero de capitulo
	$ncapitulo=$_REQUEST["ncapitulo"]; 
	#fecha de creacion del manga
	if(isset($manga)){
		  $carpetaDestino="$manga/"; #carpeta que tendrá el nombre del manga.
		$dircompleto="$nom/$manga/$version/$ncapitulo";
	}
	$carpetaversion="$version/";
	
	$carpetacapitulo="$ncapitulo/";
	#definimos la carpeta que ira dentro de destino/version/capitulo
	$carpetausuario="$nom/";
	
	
	# si hay algun archivo que subir
    if($_FILES["archivo"]["name"][0])
    {
         # recorremos todos los arhivos que se han subido
        for($i=0;$i<count($_FILES["archivo"]["name"]);$i++)
        {
		   # si es un formato de imagen
            if($_FILES["archivo"]["type"][$i]=="image/jpeg" || $_FILES["archivo"]["type"][$i]=="image/pjpeg" || $_FILES["archivo"]["type"][$i]=="image/gif" || $_FILES["archivo"]["type"][$i]=="image/png")
            {	
			#si es version  se crea una subcarpeta
				if(file_exists($carpetausuario) || @mkdir($carpetausuario))
				{
					if(file_exists($carpetausuario.$carpetaDestino) || @mkdir($carpetausuario.$carpetaDestino,true))
					{
						if(file_exists($carpetausuario.$carpetaDestino.$carpetaversion) || @mkdir($carpetausuario.$carpetaDestino.$carpetaversion,true))
						{
							if(file_exists($carpetausuario.$carpetaDestino.$carpetaversion.$carpetacapitulo) || @mkdir($carpetausuario.$carpetaDestino.$carpetaversion.$carpetacapitulo,true))
							{
								$origen=$_FILES["archivo"]["tmp_name"][$i];
								$destino=$carpetausuario.$carpetaDestino.$carpetaversion.$carpetacapitulo.$_FILES["archivo"]["name"][$i];
								# movemos el archivo
								if(@move_uploaded_file($origen, $destino))
								{
									echo "<br>".$_FILES["archivo"]["name"][$i]." movido correctamente";
								}else{
									echo "<br>No se ha podido mover el archivo: ".$_FILES["archivo"]["name"][$i];
									}
							}
							
						}
						
					}
					
				}		   
		   }else{
                echo "<br>".$_FILES["archivo"]["name"][$i]." - NO es imagen jpg";
            }
        }
    }else{
        echo "<br>No se ha subido ninguna imagen";
		
    }
	?>