<?php 
session_start();

if (isset($_SESSION["inicioSesion"])){
	$nick=$_SESSION["inicioSesion"];

}else{
	$nick=null;

}

if (isset($_SESSION["administrador"])){
	$admin=$_SESSION["administrador"];

}else{
	$admin=null;

	
}

if (isset($_SESSION["moderador"])){
	$mod=$_SESSION["moderador"];

}else{
	$mod=null;

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<!-- viewport meta to reset iPhone inital scale -->
<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
<title>Manga's Umbrella Corporation</title>
		<!-------------------------------------------------- css3-mediaqueries.js for IE8 or older----------------------------->
		<link rel="shortcut icon" type="image/x-icon" href="../style/imagenes/favicon.ico" />
		<!-------------------------------------------------- css3-mediaqueries.js for IE8 or older----------------------------->
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
		<!------------------------------------------------------------ CSS------------------------------------------------>
		<link href="../style/style.css" rel="stylesheet" type="text/css" media="screen" />
		<!------------------------------------------------------------ Bootstra------------------------------------------------>
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.1/themes/base/jquery-ui.css" />
		<!------------------------------------------------------------ JQUERY------------------------------------------------->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
		<script src="http://code.jquery.com/ui/1.10.1/jquery-ui.js"></script>
		<!------------------------------------------------------------ Java scrips ------------------------------------------------->
		<script src="../javaScripts/login.js"></script>
		<script src="../javaScripts/mostrarFormManga.js"></script>
		<!------------------------------------------------------------Coreusel------------------------------------------------->
		  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	</head>

	<body>
		<!------------------------------------------------------------PAGEWRAP------------------------------------------------->
		<div id="pagewrap">
				<!------------------------------------------------------------NAV------------------------------------------------->
		<nav class="navbar navbar-inverse  navbar-fixed-top" role="navigation">
		
			
			<!-- El logotipo y el icono que despliega el menú se agrupan
				para mostrarlos mejor en los dispositivos móviles -->
			<div class="navbar-header">
			<button type="button" class="navbar-toggle" data-toggle="collapse"
            data-target=".navbar-ex1-collapse">
			<span class="sr-only">Desplegar navegación</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			
			<a class="navbar-brand navbar-right" href="#"> <img src="../style/imagenes/simbolo.png" id="medida1" >Manga's Umbrella	</a>
		</div>
			
 
			<!-- Agrupar los enlaces de navegación, los formularios y cualquier
			otro elemento que se pueda ocultar al minimizar la barra -->
			<div class="collapse navbar-collapse navbar-ex1-collapse"> 
			<ul>
					
					  <li><a href="../index.php" class="btn btn-info">Inicio</a></li>
					  <li><a href="mangas.php" class="btn btn-info">Mangas</a></li>
					   <li><a href="noticias.php" class="btn btn-info">Noticias</a></li>
					   
					   <?php if ($admin!=null || $mod != null){?>
					    <li><a href="Control_Administrador.php" class="btn btn-info">Controll</a></li>
					   <?php }?>
					   <?php if ($nick!=null){ ?>
					   <li><a href="donaciones.php" data-paypal-button="true">
						<img src="https://www.paypalobjects.com/webstatic/en_US/btn/btn_donate_92x26.png" alt="Donate with Paypal" />
						</a></li>
					   <?php } if ($nick==null){?>
					  <li><a href="registrarse.php" class="btn btn-info">Registrate</a></li>
					   <!-- Login Starts Here -->
					   
						<li id="login">
					    <div id="loginContainer">
						<div id="loginButton">
						<a href="#" id="loginButton" class="btn btn-warning"><span>Login</span><em></em></a>
						<div style="clear:both"></div>
						<div id="loginBox">
						    <form id="loginForm" action="../controller/login.php" method="post" name="login_form">
						    <fieldset id="body">
								<?php if (isset($_SESSION["inicioSesionFallida"])){?>
								<fieldset>
								<label id="inicioSesionFallida">Inicio Sesion Incorrecto</label>
								<?php }?>
							    <fieldset>
								<label for="email">Email  <input type="text" name="correo" id="email" /></label>
							       
							    </fieldset>
							    <fieldset>
								<label for="password">Contraseña  <input type="password" name="contrasena" id="password" /></label>
							       
							    </fieldset>
							    <input type="submit" id="login" value="Entrar"  class="btn btn-info" onclick="formhash(this.form, this.form.password);"/>
							    <!--  <label for="checkbox"><input type="checkbox" id="checkbox" />Recuerdame</label> -->
							</fieldset>
							<!--<span><a href="#">Has olvidado la contraseña?</a></span> -->
						    </form>
						</div>
						</div>
					    </div>
					  </li>
					  <?php }else{?>
				      <li id="loginContainer">
						<div class="btn-group">
					  <button type="button"  data-toggle="dropdown"  class="btn btn-info dropdown-toggle">
					   <span class="glyphicon glyphicon-user">&nbsp;</span><?php echo $nick;?><span class="caret"></span>
					  </button>
					 
					  <ul class="dropdown-menu" role="menu">
					    <li><a href="perfil_usuario.php">Ver mi perfil</a></li>
					    <li><a href="../controller/cerrar_sesion.php">Cerrar Sesion</a></li>
					  </ul>
					</div></li>
					  <?php }?>
					 <!-- Login Ends Here -->
				</ul>
		 
		
		  </div>
		</nav>
			<!------------------------------------------------------------ FINAL NAV------------------------------------------------->
			<!------------------------------------------------------------ HEADER------------------------------------------------->
	
			<div id="header">
				<div id="topc">
				<h3>Subir Mangas</h3>
				</div>
				<div id="fondosBlancos">
					<p><font color="#00cd89">
					 Subir manga o capitulo:
					<br />
					<button type="button" class="btn btn-primary btn-lg" onClick="mostrar('manga');" >Manga</button>
					<button type="button" class="btn btn-primary btn-lg" onClick="mostrar('capitulo');" >Capítulo</button>
					</font>
						<div  id="manga" style="display: none;">
						
								<h2>Subir Manga </h2>
								<form action="../controller/recibeimg.php" method="post" enctype="multipart/form-data" name="inscripcion">
									<p><font color="#00cd89">
									Usuario: <input class="form-control" type="text" name="txtnom" autofocus required  />
									<br />
									Título (100/100):<input class="form-control"type="text" name="titulo"  required />
									<br />
									Imagen Portada: <input  type="file"  name="portada">
									<br />
									
									Fecha publicación (De la obra original) <input class="form-control" type="date" name="fecha"  min="1900-01-01" max="2016-12-31" >
									<br />
									Genero de manga:<br />
												<label class="checkbox-inline">
												<input type="checkbox"  name="genero[]"  value="accion"> Acción
												</label>
												<label class="checkbox-inline">
												<input type="checkbox"   name="genero[]"  value="apocaliptico"> Apocalíptico
												</label>
												<label class="checkbox-inline">
												<input type="checkbox"  name="genero[]"  value="aventura"> Aventura
												</label>
												<br/>
												<label class="checkbox-inline">
												<input type="checkbox"   name="genero[]"  value="terror"> Terror
												</label >
												<label class="checkbox-inline">
												<input type="checkbox"    name="genero[]"  value="ecchi"> Ecchi
												</label>
												 <label class="checkbox-inline">
												<input type="checkbox"  name="genero[]"  value="comedia"> Comedia
												</label>
									<br /><br />
									Periodicidad (De la obra original) <select  class="form-control" name="periocidad" >
																		<option>Seleccione un valor</option>
																		<option value="sinespecificar">Sin especificar</option>
																		<option value="semanal">Semanal</option>
																		<option value="quincenal">Quincenal</option>
																		<option value="mensual">Mensual</option>
																	 </select>
									<br />
									Estado (En MangasUmbrella Corporation) <select class="form-control" name="estado" >
																		<option>Seleccione un valor</option>
																		<option value="sinespecificar">Sin especificar</option>
																		<option value="activo">Activo</option>
																		<option value="abandonado">Abandonado</option>
																		<option value="finalizado">Finalizado</option>
																	 </select>
									<br />
									Contenido adulto:<br />
									<div class="radio">
										  <label>
											<input type="radio" name="adulto" id="adulto" value="adulto">
											Escenas de extrema violencia y desnudos con censura. (En MangasUmbrella Corporation no esta permitido publicar Hentai). 
										  </label>
									</div>
									Sinopsis (1000/1000): <br />
									<textarea class="form-control" rows="3" placeholder="Este manga va de..." name="sinopsis" required></textarea>
									
									<br/><br />
									Número de capítulo <input class="form-control" type="text" name="ncapitulo"  required />
									<br />
									Número de página <input class="form-control" type="text" name="npaginas"  required />
									<br />
									Version: <select class="form-control" name="version">
												<option>Seleccione una versión</option>
												<option value="esp">Español</option>
												<option value="eng">Ingles</option>
											 </select>
									<br />
									Autores: <input class="form-control" type="text" name="autor" />
									<br />
									Artistas:  <input class="form-control" type="text" name="artista" />
									<br />
									</p>
									</font>
									Imagenes para el capitulo (Recuerda los nombres de las imagenes deben ser numeros consecutivos empezando por 1. Ej. "1,2,3...")
									<input type="file" name="archivo[]" multiple="multiple">
									 <input type="submit" value="Enviar" >
								
								</form>
						</div>
						<div id="capitulo" style="display: none;">
						
								<h2>Subir Capitulo </h2>
								<form action="../controller/recibecapi.php" method="post" enctype="multipart/form-data" name="inscripcion">
									<p><font color="#00cd89">
									Usuario: <input type="text" class="form-control" name="txtnom" autofocus required  />
									<br />
									Manga
									<select  class="form-control" name="manga" required >
										<option>Seleccione un valor</option>
										<option value="naruto">Naruto</option>
										<option value="onepiece">OnePiece</option>
										<option value="swordartonline">Sword Art Online</option>
										<option value="nogamenolife">No Game No life</option>
									 </select>
									
									Número de capítulo <input class="form-control" type="text" name="ncapitulo"  required />
									<br />
									Número de página <input class="form-control" type="text" name="npagina"  required />
									<br />
									Version:
									<select class="form-control" name="version" required>
												<option>Seleccione una versión</option>
												<option value="esp">Español</option>
												<option value="eng">Ingles</option>
									</select>
									
									<br />
									</p>
									</font>
									
									<input type="file" name="archivo[]" multiple="multiple" >
									 <input type="submit" value="Enviar"  class="trig"  >
								
								</form>
						</div>

				
				
				
				  </div>	
			<!------------------------------------------------------------ FINAL Fondos blancos------------------------------------------------->
		   					
			<!------------------------------------------------------------ FINAL HEADER------------------------------------------------->
			
			<!------------------------------------------------------------FOOTER------------------------------------------------->
			<footer>
				<p>&copy; Designet and Created by Judit CerdÃ  Izquierdo and Ibis Emmanuel</p>
			</footer>
			<!------------------------------------------------------------FINAL FOOTER------------------------------------------------->
		</div>
		<!------------------------------------------------------------  FINAL PAGEWRAP------------------------------------------------->

	</body>
</html>


