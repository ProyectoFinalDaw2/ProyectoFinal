<?php
	//require_once '../db/db_connect.php';
	function conectar()
	{
	$ip = 'localhost';
	$usuari = 'root';
	$password = '1234';
	$db_name = 'mangas';
	
	$con = mysqli_connect($ip,$usuari,$password);
	mysqli_select_db($con,$db_name);
	
	return $con;
	}
	

	#Procesamos los datos del manga.
	session_start();
	#nombre de usuario
	$nom=$_REQUEST["txtnom"]; 
	#titulo del manga para capitulos, cuando ya exista
	$titulo=$_REQUEST["titulo"]; 
	$titulo=strtolower(str_replace(' ', '',$titulo));
	
	#seleccionamos la version
	if(isset($_POST["version"]))
	{
	$version=$_POST["version"];   //version del manga  esp o ingles
	}	
	#numero de capitulo
	$ncapitulo=$_REQUEST["ncapitulo"]; 
	#fecha de creacion del manga
	$fecha=$_REQUEST["fecha"];
	//echo $fecha;
	#Genero del manga, checkbox multiple
	$array[]=null;
	if($_POST['genero'] != "")
	  {
		if(is_array($_POST['genero']))
		{
		  while(list($key,$value) = each($_POST['genero'])) 
		  {
				$array[]=$value;
				/*$con=conectar();
				$sqlcheckbox = "INSERT INTO manga (genero) VALUES ('$value')";
				$resultat = mysqli_query($con, $sqlcheckbox);*/
			  /*		 
		 $sql=mysql_query("INSERT INTO prueba (nombre, deporte) VALUES ('$nombre','$value')");*/
		 }
	   }
	 }
	 #seleccionamos la periocidad de publicacion del manga.
		if(isset($_POST["periocidad"]))
		{
		$periocidad=$_POST["periocidad"];   //periocidad del manga.
		}	
	#seleccionamos el estado del manga en mangasumbrella corporation
		if(isset($_POST["estado"]))
		{
		$estado=$_POST["estado"];   //estado del manga.
		}
	#Comprobamos si el contenido sera para mayores de 18 o apto para todo publico
	if(isset($_POST["adulto"]))
		{
		$adulto=$_POST["adulto"];   //SI el contenido es para adulto.
		}
	#Añadimos la variable de sinopsis 
	$sinopsis=$_REQUEST["sinopsis"];
	#Nº de paginas
	$npaginas=$_REQUEST["npaginas"];
	#Añadimos el autor
	$autor=$_REQUEST["autor"];
	#Añadimos el artista
	$artista=$_REQUEST["artista"];	
	#añadimos version a la nueva carpeta
	$carpetaversion="$version/";
	
	#definimos la carpeta que ira dentro de destino/version/capitulo
	#Primero añadimos un if para definir si viene de capitulo o de manga nuevo.

	$carpetacapitulo="$ncapitulo/";
	
	if(isset($titulo)){
		
		$carpetaDestino="$titulo/";
		$dircompleto="$nom/$titulo/$version/$ncapitulo";
	}

	#definimos la carpeta que ira dentro de destino/version/capitulo
	$carpetausuario="$nom/";
	#creamos la carpeta portada
	$carpetaportada='portada/';
	#carpeta contenedora de la portada
	$dirportada=$carpetausuario.$carpetaDestino.$carpetaportada;
	#insertamos los datos
						$con=conectar();
						echo $dircompleto;
						$sqlmanga="INSERT INTO mangas.manga (IDMANGA,titulo,imgportada,fechapubliobr,genero,periocidad,estado,adulto,sinopsis,autores,artistas) 
											  VALUES ('1','$titulo','$dirportada','2014/12/12','accion','$periocidad','$estado','$adulto','$sinopsis','$autor','$artista')";
						/*$sqlsube = "INSERT INTO mangas.sube (link,npaginas,capitulo,global,semanal) VALUES ('$dircompleto','$npaginas','$ncapitulo')";
						$resultat = mysqli_query($con, $sqlsube);*/
						$resul2=mysqli_query($con,$sqlmanga) ;
	#Si versión null, defecto, en blanco. La ponemos por defecto en español
	if($version==null)$version="esp";
	
	# si hay algun archivo que subir
    if($_FILES["archivo"]["name"][0])
    {
         # recorremos todos los arhivos que se han subido
        for($i=0;$i<count($_FILES["archivo"]["name"]);$i++)
        {
		   # si es un formato de imagen
            if($_FILES["archivo"]["type"][$i]=="image/jpeg" || $_FILES["archivo"]["type"][$i]=="image/pjpeg" || $_FILES["archivo"]["type"][$i]=="image/gif" || $_FILES["archivo"]["type"][$i]=="image/png")
            {	
			#si es version  se crea una subcarpeta
				if(file_exists($carpetausuario) || @mkdir($carpetausuario))
				{
					if(file_exists($carpetausuario.$carpetaDestino) || @mkdir($carpetausuario.$carpetaDestino,true))
					{
						if(file_exists($carpetausuario.$carpetaDestino.$carpetaversion) || @mkdir($carpetausuario.$carpetaDestino.$carpetaversion,true))
						{
							if(file_exists($carpetausuario.$carpetaDestino.$carpetaversion.$carpetacapitulo) || @mkdir($carpetausuario.$carpetaDestino.$carpetaversion.$carpetacapitulo,true))
							{
								$origen=$_FILES["archivo"]["tmp_name"][$i];
								$destino=$carpetausuario.$carpetaDestino.$carpetaversion.$carpetacapitulo.$_FILES["archivo"]["name"][$i];
								# movemos el archivo
								if(@move_uploaded_file($origen, $destino))
								{
									echo "<br>".$_FILES["archivo"]["name"][$i]." movido correctamente";
								}else{
									echo "<br>No se ha podido mover el archivo: ".$_FILES["archivo"]["name"][$i];
									}
							}
							
						}
						
					}
					
				}		   
		   }else{
                echo "<br>".$_FILES["archivo"]["name"][$i]." - NO es imagen jpg";
            }
        }
    }else{
        echo "<br>No se ha subido ninguna imagen";
		
    }
	
	#FOTO DE PORTADA
	if($_FILES['portada']['name'])
    {
         # si es un formato de imagen
            if($_FILES["portada"]["type"]=="image/jpeg" || $_FILES["portada"]["type"]=="image/pjpeg" || $_FILES["portada"]["type"]=="image/gif" || $_FILES["portada"]["type"]=="image/png")
            {	
			
			#Si existe la carpeta, lo mas probable se guarda la portada.
					if(file_exists($carpetausuario.$carpetaDestino.$carpetaportada) || @mkdir($carpetausuario.$carpetaDestino.$carpetaportada,true))
						{		 
								
								
								$origen=$_FILES["portada"]["tmp_name"];
								$destino=$carpetausuario.$carpetaDestino.$carpetaportada.$_FILES["portada"]["name"];
								# movemos el archivo
								if(@move_uploaded_file($origen, $destino))
								{
									echo "<br>".$_FILES["portada"]["name"]." movido correctamente";
								}else{
									echo "<br>No se ha podido mover el archivo: ".$_FILES["portada"]["name"];
									}
							}else{
								echo "<br>No se ha podido crear la carpeta: up/".$user;
							}
			#hasta aqui la creacion de la carpeta  de img
		      }else{
                echo "<br>".$_FILES["portada"]["name"]." - NO es imagen jpg";
				}
	}else{
        echo "<br>No se ha subido ninguna imagen";
			}			
?>