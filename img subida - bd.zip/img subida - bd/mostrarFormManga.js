function mostrar(id) {
    if (id == "manga") {
        $("#manga").show();
        $("#capitulo").hide();
    }

    if (id == "capitulo") {
        $("#manga").hide();
        $("#capitulo").show();
    }
}