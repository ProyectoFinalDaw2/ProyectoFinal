<?php

	/**
	 * Estos son los detalles de inicio de sesi�n de la base de datos: 
	*/  
	/*define("HOST", "localhost");     // El alojamiento al que deseas conectarte
	define("USER", "emmanuel");    // El nombre de usuario de la base de datos
	define("PASSWORD", "V6ednr2SeNEstqDX");    // La contrase�a de la base de datos
	define("DATABASE", "mangas");    // El nombre de la base de datos
	 
	define("CAN_REGISTER", "any");
	define("DEFAULT_ROLE", "member");
	 
	define("SECURE", FALSE);    // ���SOLO PARA DESARROLLAR!!!!*/

	/**
	 * Estos son los detalles de inicio de sesi�n de la base de datos: 
	 */  
	define("HOST", "localhost");     // El alojamiento al que deseas conectarte
	define("USER", "root");    // El nombre de usuario de la base de datos
	define("PASSWORD", "root");    // La contrase�a de la base de datos
	define("DATABASE", "mangaonline");    // El nombre de la base de datos
	 
	define("CAN_REGISTER", "any");
	define("DEFAULT_ROLE", "member");
	 
	define("SECURE", FALSE);    // ���SOLO PARA DESARROLLAR!!!!

?>